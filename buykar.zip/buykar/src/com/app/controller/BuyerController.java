package com.app.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.IBuyer;
import com.app.dao.ICart;
import com.app.dao.IOrder;
import com.app.dao.IProduct;
import com.app.pojos.Buyer;
import com.app.pojos.Cart;
import com.app.pojos.Order;
import com.app.pojos.Product;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/buyer")
public class BuyerController {

	
	@Autowired
	private IBuyer dao;
	
	@Autowired
	private ICart cdao;
	
	@Autowired
	private IProduct pdao;
	
	@Autowired
	private IOrder odao;
	
	
	@GetMapping("/{email}/{password}")
	public ResponseEntity<?> getBuyerDetails(@PathVariable String email,@PathVariable String password)
	{
		
		Buyer b=dao.authenticateBuyer(email, password);
		
		//System.out.println(b);
		if(b!=null)
		{
			return new ResponseEntity<Buyer>(b, HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<String>("invalid login", HttpStatus.NO_CONTENT);
		}
	}
	
	
	
	
	  @PostMapping 
	  public ResponseEntity<String> addBuyer(@RequestBody Buyer b) 
	  {
		  System.out.println(b);
	  try 
	  {
	  
	  return new ResponseEntity<String>(dao.addBuyer(b),HttpStatus.OK); 
	  }
	  catch(RuntimeException e) 
	  { 
		  return new ResponseEntity<String>("error"+e.getMessage(), HttpStatus.NO_CONTENT); 
		  } 
	  }
	  
	  
	  @GetMapping("/cart/{bid}/{pid}")
	  public ResponseEntity<Boolean> removeFromCart(@PathVariable int bid , @PathVariable int pid)
	  {
		  try {
			
			  
			  return new ResponseEntity<Boolean>(cdao.deletefromCart(bid, pid),HttpStatus.OK);
		  
		  }
		  catch(RuntimeException e) 
		  { 
			  return new
		  ResponseEntity<Boolean>(false, HttpStatus.NO_CONTENT); 
			  }
	  }
	  
	
	  @RequestMapping(value = "/cart/{bid}/{pid}/{quantity}",method = RequestMethod.GET)
	  public ResponseEntity<String> addToCart(@PathVariable int bid , @PathVariable int pid , @PathVariable int quantity)
	  {
		//  System.out.println("-------------------------"+bid+pid+quantity);
		  try 
		  {
			 
		  return new ResponseEntity<String>(cdao.addToCart(bid,pid,quantity),HttpStatus.OK); 
		  }
	
		 
  
		  
		  catch(RuntimeException e) 
		  { 
			  return new
		  ResponseEntity<String>("error"+e.getMessage(), HttpStatus.NO_CONTENT); 
			  } 
}
	  
	  
	  @GetMapping("/cart/{bid}")
		public ResponseEntity<?> viewCart(@PathVariable int bid)
		{
		
			List<Cart> cl=cdao.viewCart(bid);
			if(cl.size()==0)
			{
				return new ResponseEntity<String>("no contents in cart ", HttpStatus.NO_CONTENT);
			}
			else
			{
				return new ResponseEntity<List<Cart>>(cl, HttpStatus.OK);
			}
		}
	  
	  @GetMapping("/order/add/{bid}")
	  public ResponseEntity<Boolean> placeOrder(@PathVariable int bid)
	  {
		  try {
			  Date d = new Date();
		  
			 Buyer b =dao.getBuyerById(bid);
			 Order o = new Order();
			 o.setBid(bid);
			 o.setNoProduct(cdao.getNoProduct(bid));
			 o.setTotalAmount(cdao.getTotalAmount(bid));
			 o.setOrderDate(d);
			 
			 
			 
			 return new ResponseEntity<Boolean>(odao.placeOrder(o),HttpStatus.OK); 
	  }
	  catch(RuntimeException e) 
	  { 
		  return new
	  ResponseEntity<Boolean>(false, HttpStatus.NO_CONTENT); 
		  } 
			 
	  }
	  
	  @GetMapping("/order/{bid}")
	  public ResponseEntity<?> getBuyersTodaysOrderDetails(@PathVariable int bid)
		{
		 // List<Cart> cl=cdao.viewCart(bid);
		  Order o = odao.getBuyersTodaysOrderDetails(bid);
		  System.out.println(o);
			try {
				return new ResponseEntity<Order>(o, HttpStatus.OK);
				
			}
			catch (Exception e) {
				return new ResponseEntity<Boolean>(false, HttpStatus.NO_CONTENT);
			}
			
		}
	  
	 
	
	
}
