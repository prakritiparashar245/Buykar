package com.app.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.IProduct;
import com.app.dao.ISeller;
import com.app.pojos.Product;
import com.app.pojos.Seller;


@RestController
@CrossOrigin(origins = "http://localhost:4200") 
@RequestMapping("/seller")
public class SellerController
{
	@Autowired
	private ISeller sdao;
	
	@Autowired
	private IProduct pdao;
	
	
	@GetMapping("/{email}/{password}")
	public ResponseEntity<?> getSellerloginDetails(@PathVariable String email, @PathVariable String password)
	{
		Seller s = sdao.authenticateSeller(email, password);
		
		
		//Seller s1=(Seller) hs.getAttribute("seller_dtls");
		//System.out.println("-----" + s1);
		if(s!=null)
		{
			return new ResponseEntity<Seller>(s, HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<String>("invalid details", HttpStatus.NO_CONTENT);
		}
		
	}
	
	
	@PostMapping 
	public ResponseEntity<String> addSeller(@RequestBody Seller s) 
	  {
	  try 
	  {
		  return new ResponseEntity<String>(sdao.addSeller(s),HttpStatus.OK); 
	  }
	  catch(RuntimeException e) 
	  { 
		  return new
		  ResponseEntity<String>("error"+e.getMessage(), HttpStatus.NO_CONTENT); 
	  } 
	  }
	
	
	// REST service method to update existing stock
		@PutMapping("/{sid}/{pid}")
		public ResponseEntity<Boolean> updateProduct(@PathVariable int sid,@PathVariable int pid, @RequestBody Product p) {
			System.out.println("in update product " + pid + " " + p);
			
			Product eP = sdao.getProductBySidPid(sid, pid);
			Seller s=sdao.getSellerBYId(sid);
			if (eP != null) {
				eP.setPid(pid);
				eP.setDescription(p.getDescription());
				eP.setImage(p.getImage());
				eP.setMaterial(p.getMaterial());
				eP.setPname(p.getPname());
				eP.setPrice(p.getPrice());
				eP.setQuantity(p.getQuantity());
				eP.setType(p.getType());
				eP.setSid(s);
				
				try {
					return new ResponseEntity<Boolean>(sdao.updateProduct(eP), HttpStatus.OK);
				} catch (RuntimeException e) {
					return new ResponseEntity<Boolean>(false,
							HttpStatus.INTERNAL_SERVER_ERROR);
				}
			}
			return new ResponseEntity<Boolean>(false, HttpStatus.NOT_FOUND);

		}
	
	
	  
	
	@GetMapping("/{sid}")
	public ResponseEntity<?> showMyProduct(@PathVariable int sid)
	{
		try {
			return new ResponseEntity<List<Product>>(sdao.showMyProduct(sid), HttpStatus.OK);
		}
		catch(RuntimeException e)
		{
			return new ResponseEntity<String>("seller id does not exist",HttpStatus.NO_CONTENT);
		}

	}	
	
	
	
	
	
	 @PostMapping("/product/{sid}")
	  public ResponseEntity<Boolean> addProduct(@RequestBody Product p, @PathVariable int sid)
	  { 
		
	  try 
	  	{ 
		  
		  return new ResponseEntity<Boolean>(sdao.addProduct(p, sid),HttpStatus.OK); 
		 }
	  catch(RuntimeException e)
	  { 
		  return new ResponseEntity<Boolean>(false, HttpStatus.NO_CONTENT);
	  }
	}
	 
	 @DeleteMapping("/{pid}")
	 public ResponseEntity<String> deleteProduct( @PathVariable int pid)
	  { 
		 return new ResponseEntity<String>(sdao.deleteProduct(pid),HttpStatus.OK); 
	  }
	 
	
	
	
	  } 

