package com.app.dao;


import java.util.List;

import com.app.pojos.Product;
import com.app.pojos.Seller;

public interface ISeller
{
	List<Seller> showAllSellers();
	
	Seller authenticateSeller(String email,String password);
	String addSeller(Seller s);
	boolean addProduct(Product p,int sid);
	boolean updateProduct(Product p);
	String deleteProduct(int pid);
	
	List<Product> showMyProduct(int sid);
	Seller getSellerBYId(int sid);
	Product getProductBySidPid(int sid,int pid);
	
}
