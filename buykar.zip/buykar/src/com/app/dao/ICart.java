package com.app.dao;

import java.util.List;

import com.app.pojos.Cart;


public interface ICart 
{
	List<Cart> viewCart(int bid);
	
	String addToCart(int bid,int pid ,int qty);
	boolean deletefromCart(int bid, int pid);
	
	double getTotalAmount(int bid);
	int getNoProduct(int bid);
	
}
