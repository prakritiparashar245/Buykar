package com.app.dao;

import java.util.List;

import com.app.pojos.Order;

public interface IOrder 
{
	Boolean placeOrder(Order o);
	Order getBuyersTodaysOrderDetails(int bid);
	List<Order> getOrderHistory();
}
