package com.app.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Buyer;
import com.app.pojos.Cart;
import com.app.pojos.Product;

@Repository
@Transactional
public class CartDaoImpl implements ICart
{

	@Autowired
	private SessionFactory sf;
	
	@Autowired
	private IProduct pdao;
	

	@Autowired
	private IBuyer bdao;
	
	
	@Override
	public String addToCart(int bid,int pid,int qty) 
	{
		 Buyer b =bdao.getBuyerById(bid);
		  //System.out.println("---*******--"+b);
		  
	  Product p = pdao.getProductById(pid);
	 //System.out.println(p.getQuantity()+"****"+qty);
	 Cart c = new Cart();
	  if(p.getQuantity() >  qty )
	  {
	 
	 
	  c.setpId(pid);
	  c.setProductName(p.getPname());
	  c.setProductPrice(p.getPrice());
	  c.setQuantity(qty);
	  c.setBuyerId(b);
	 // System.out.println("-----"+c);
	 
	 pdao.subtractProductQuantity(pid, qty);
	  }
		
		sf.getCurrentSession().save(c);
		return " Added to Cart";
		
	}

	@Override
	public boolean deletefromCart(int bid, int pid)
	{
		//System.out.println("----");
	 Cart c = sf.getCurrentSession().createQuery("select c from Cart c where c.buyerId.bid=:bid and c.pId=:pid", Cart.class).setParameter("bid", bid).setParameter("pid", pid).getSingleResult();
		//System.out.println(c);
	 
	 pdao.addProductQuantity(c.getpId(), c.getQuantity());
		/////c.getQuantity();
		if(c!=null)
		{
			sf.getCurrentSession().delete(c);
			return true;
		}
		
			return false;
		
	}

	@Override
	public List<Cart> viewCart(int bid) {
		
		return sf.getCurrentSession().createQuery("select c from Cart c where c.buyerId.bid=:bid", Cart.class).setParameter("bid", bid).getResultList();

	}

	@Override
	public double getTotalAmount(int bid) 
	{
		//List<Cart> cartItems = sf.getCurrentSession().createQuery("select c from Cart c where c.buyerId.bid=:bid", Cart.class).setParameter("bid", bid).getResultList();
		List<Cart> cartItems = viewCart(bid);
		double total=0;
		for(Cart cart : cartItems) 
		{
			total += cart.getProductPrice()*cart.getQuantity();
		}
		System.out.println("Total---------"+total);
		return total;
	}

	@Override
	public int getNoProduct(int bid)
	{
		List<Cart> cartItems = viewCart(bid);
		int no=0;
		for(Cart cart : cartItems) 
		{
			no++;
		}
		System.out.println("NO---------"+no);
		return no;
		
	}
	
}




