package com.app.dao;


import com.app.pojos.Buyer;

public interface IBuyer {

	Buyer authenticateBuyer(String email,String password);
	String addBuyer(Buyer u);
	Buyer getBuyerById(int bid);
}
