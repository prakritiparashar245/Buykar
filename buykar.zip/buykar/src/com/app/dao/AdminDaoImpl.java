package com.app.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Admin;


@Repository
@Transactional
public class AdminDaoImpl implements IAdmin
{
	@Autowired
	private SessionFactory sf;

	@Override
	public Admin authenticateAdmin(String email, String password) {
		String jpql = "select a from Admin a where a.email=:email and a.password=:password";
			return sf.getCurrentSession().createQuery(jpql, Admin.class).setParameter("email", email).setParameter("password", password).getSingleResult();
			
	}
}
