package com.app.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.app.pojos.Buyer;
import com.app.pojos.Seller;

@Repository
@Transactional
public class BuyerDAOImpl implements IBuyer
{
	
	@Autowired
	private SessionFactory sf;

	@Override
	public Buyer authenticateBuyer(String email, String password)
	{
		
		String jpql = "select b from Buyer b where email=:email and password=:password";
	//	System.out.println("-----"+sf.getCurrentSession().createQuery(jpql, Buyer.class).setParameter("email", email).setParameter("password", pass).getSingleResult()); 
		
		return sf.getCurrentSession().createQuery(jpql, Buyer.class).setParameter("email", email).setParameter("password", password).getSingleResult();
		}

	@Override
	public String addBuyer(Buyer b) {
		// TODO Auto-generated method stub
		sf.getCurrentSession().save(b);
		return " Buyer registered ";
	}

	@Override
	public Buyer getBuyerById(int bid) {
		// TODO Auto-generated method stub
		
		Buyer    b = sf.getCurrentSession().createQuery("select b from Buyer b where b.bid=:bid",Buyer.class).setParameter("bid", bid).getSingleResult();
		//System.out.println(b);
		return b;
	}
}

