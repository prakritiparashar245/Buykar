package com.app.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Order;
import com.app.pojos.Product;

@Repository
@Transactional
public class OrderDaoImpl implements IOrder
{
	@Autowired
	private SessionFactory sf;

	@Override
	public Boolean placeOrder(Order o)
	{
		sf.getCurrentSession().save(o);
		return true;
	}

	@Override
	public Order getBuyersTodaysOrderDetails(int bid)
	{
		//Date d = new Date(year, month, date);
		Order o= sf.getCurrentSession().createQuery("select o from Order o where o.bid=:bid ", Order.class).setParameter("bid", bid).getSingleResult();
		System.out.println(o);
		return o;
		
	}

	@Override
	public List<Order> getOrderHistory() {
		return sf.getCurrentSession().createQuery("select o from Order o ", Order.class).getResultList();
	}
}
