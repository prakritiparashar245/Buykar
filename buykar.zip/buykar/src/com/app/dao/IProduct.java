package com.app.dao;

import java.util.List;


import com.app.pojos.Product;

public interface IProduct {
	
	Product getProductById(int id);
	
	List<Product> getallproduct();
	List<Product> getProductByMaterial(String material);
	List<Product> getProductByType(String type);
	
	void subtractProductQuantity(int pid, int no);
	
	void addProductQuantity(int pid, int no);
	
	
	
}
