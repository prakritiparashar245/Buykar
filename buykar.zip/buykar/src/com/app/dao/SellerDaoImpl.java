package com.app.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Product;
import com.app.pojos.Seller;

@Repository
@Transactional
public class SellerDaoImpl implements ISeller
{
	@Autowired
	private SessionFactory sf;

	@Override
	public Seller authenticateSeller(String email, String password) 
	{
		String jpql = "select s from Seller s where email=:email and password=:password";
		Seller s = sf.getCurrentSession().createQuery(jpql, Seller.class).setParameter("email", email).setParameter("password", password).getSingleResult();
	
		return s;
	}

	@Override
	public String addSeller(Seller s) {
		// TODO Auto-generated method stub
				sf.getCurrentSession().save(s);
				return " Seller registered ";
	}
	
	@Override
	public boolean addProduct(Product p,int sid)
	{
		 Seller s =getSellerBYId(sid);
		 p.setSid(s);
		//System.out.println(p);
		//System.out.println("sellerdao"+p);
	//	Product p1=new Product("ravi","test","test1", 500.00,"desc",new Integer(300));
		//p.setSid(sid);
		//System.out.println(p);
		sf.getCurrentSession().save(p);
		
		//Seller seller= sf.getCurrentSession().get(Seller.class,sid.getSid());
		//seller.AddProduct(p);
		
		return true;
	}



	@Override
	public List<Product> showMyProduct(int sid)
	{
		
		List<Product> s= sf.getCurrentSession().createQuery("select p from Product p where p.sid.sid=:sid",Product.class).setParameter("sid", sid).getResultList();
		/*
		 * List<Product> p= s.getLop(); for (Product product : p) {
		 * System.out.println(product.getPname()); }
		 */
		return s;
	}

	@Override
	public boolean updateProduct(Product p)
	{
		sf.getCurrentSession().update(p);
		return true;
		
	}

	@Override
	public Seller getSellerBYId(int sid) {
		String jpql="select s from Seller s where s.sid=:sid";
		return sf.getCurrentSession().createQuery(jpql, Seller.class).setParameter("sid", sid).getSingleResult();
	}

	@Override
	public Product getProductBySidPid(int sid, int pid) {
		// TODO Auto-generated method stub
		String jpql="select p from Product p where p.pid=:pid and p.sid.sid=:sid";
		return sf.getCurrentSession().createQuery(jpql,Product.class).setParameter("sid", sid).setParameter("pid", pid).getSingleResult();
	}

	@Override
	public String deleteProduct(int pid)
	{
		Session hs = sf.getCurrentSession();
		Product p =hs.get(Product.class, pid);
		if(p!=null)
		{
			hs.delete(p);
			return "product deleted with name"+p.getPname();
		}
		return "product not found";
	}

	@Override
	public List<Seller> showAllSellers() 
	{
		return sf.getCurrentSession().createQuery("select s from Seller s ", Seller.class).getResultList();
		
	}

	

	/*@Override
	public String updateProduct(Product p, Seller sid)
	{
		p.setSid(sid);
		System.out.println(p.getSid());
		sf.getCurrentSession().update(p);
		return "Product Data Updated";
	}*/

}
