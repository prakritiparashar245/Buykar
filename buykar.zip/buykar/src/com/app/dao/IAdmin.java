package com.app.dao;

import com.app.pojos.Admin;


public interface IAdmin 
{
	Admin authenticateAdmin(String email,String password);
}
