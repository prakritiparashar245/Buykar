package com.app.pojos;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "buyer",schema = "system")
public class Buyer {

	private String email;
	private String name;
	private String address;
	private String password;
	private Integer bid;
	private String phoneNo;
	private String pincode;
	@JsonIgnore
	private List<Cart> cartItems=new ArrayList<Cart>();

	
	public Buyer()
	{
		System.out.println("buyer");
	}
	
	


	@Override
	public String toString() {
		return "Buyer [email=" + email + ", name=" + name + ", address=" + address + ", password=" + password + ", bid="
				+ bid + ", phoneNo=" + phoneNo + ", pincode=" + pincode + ", cartItems=" + cartItems + "]";
	}




	public Buyer(String email, String name, String address, String password, Integer bid, String phoneNo,
			String pincode, List<Cart> cartItems) {
		super();
		this.email = email;
		this.name = name;
		this.address = address;
		this.password = password;
		this.bid = bid;
		this.phoneNo = phoneNo;
		this.pincode = pincode;
		this.cartItems = cartItems;
	}

	@Column(length = 8)
	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	

	@OneToMany(mappedBy = "buyerId",cascade = CascadeType.ALL)
	public List<Cart> getCartItems() {
		return cartItems;
	}

	public void setCartItems(List<Cart> cartItems) {
		this.cartItems = cartItems;
	}

	@Column(length = 25,unique = true)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Column(length = 20)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(length = 150)
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Column(length = 10)
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer getBid() {
		return bid;
	}

	public void setBid(Integer bid) {
		this.bid = bid;
	}


	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	
	
}
