package com.app.pojos;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "orders",schema = "system")
public class Order {

	private Integer orderId;
	private Double totalAmount;
	private Date OrderDate;
	private Integer bid;
	private Integer noProduct;
	@JsonIgnore
	private List<Cart> loc=new ArrayList<Cart>();
	
	
	
	@OneToMany(cascade = CascadeType.ALL,mappedBy = "orderId")
	public List<Cart> getLoc() {
		return loc;
	}
	public void setLoc(List<Cart> loc) {
		this.loc = loc;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	
	@Temporal(TemporalType.DATE)
	@Column(name = "orderdate")
	public Date getOrderDate() {
		return OrderDate;
	}
	public void setOrderDate(Date orderDate) {
		OrderDate = orderDate;
	}
	
	public Integer getBid() {
		return bid;
	}
	public void setBid(Integer bid) {
		this.bid = bid;
	}
	public Integer getNoProduct() {
		return noProduct;
	}
	public void setNoProduct(Integer noProduct) {
		this.noProduct = noProduct;
	}
	public Order()
	{
		
		System.out.println("order");
	}
	public Order(Double totalAmount, Date orderDate) {
		super();
		
		this.totalAmount = totalAmount;
		OrderDate = orderDate;
	
	}
	public Order(Integer orderId, Double totalAmount, Date orderDate, Integer bid, Integer noProduct, List<Cart> loc) {
		super();
		this.orderId = orderId;
		this.totalAmount = totalAmount;
		OrderDate = orderDate;
		this.bid = bid;
		this.noProduct = noProduct;
		this.loc = loc;
	}
	
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", totalAmount=" + totalAmount + ", OrderDate=" + OrderDate + ", bid="
				+ bid + ", noProduct=" + noProduct + ", loc=" + loc + "]";
	}
	
	
	
	
	
	
	
	
	
}
