package com.app.pojos;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="product",schema = "system")
public class Product 
{
	private Integer pid;
	private String pname;
	private String type;
	private String material;
	private Double price;
	private String description;
	private Integer quantity;
	@JsonIgnore
	private Seller sid;
	private String image;
	
	@Column(length = 50)
	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer getPid() {
		return pid;
	}
	
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	@Column(length = 20)
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	@Column(length = 20)
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Column(length = 20)
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}

	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	@Column(length = 100)
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	@ManyToOne
	@JoinColumn(name  = "sid")
	public Seller getSid() {
		return sid;
	}

	public void setSid(Seller sid) {
		this.sid = sid;
	}

	public Product()
	{
		System.out.println("product ");
	}

	public Product( String pname, String type, String material, Double price, String description,Integer quantity) {
		super();
	
		this.pname = pname;
		this.type = type;
		this.material = material;
		this.price = price;
		this.description = description;
		this.quantity = quantity;
	
	}

	
	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", type=" + type + ", material=" + material + ", price="
				+ price + ", description=" + description + ", quantity=" + quantity + ", sid=" + sid + ", image="
				+ image + "]";
	}

	
	
	
}
