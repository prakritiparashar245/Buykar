package com.app.pojos;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.*;
import javax.persistence.Table;

@Entity 
@Table(name = "cart", schema = "system")
public class Cart
{
	
	private Integer cId;
	private Integer pId;
	private String productName;
	private Double productPrice;
	private Integer quantity;
	private Order orderId;
	private Buyer buyerId;
	
	@ManyToOne
	@JoinColumn(name = "orderId")
	public Order getOrderId() {
		return orderId;
	}
	public void setOrderId(Order orderId) {
		this.orderId = orderId;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer getCId() {
		return cId;
	}
	public void setCId(Integer odId) {
		this.cId = odId;
	}
	
	public Integer getpId() {
		return pId;
	}
	public void setpId(Integer pId) {
		this.pId = pId;
	}
	@Column(length = 30)
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
	@ManyToOne
	@JoinColumn(name = "buyerId")
	public Buyer getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(Buyer buyerId) {
		this.buyerId = buyerId;
	}
	
	public Cart()
	{
		System.out.println("Cart");
	}
	
	
	@Override
	public String toString() {
		return "Cart [cId=" + cId + ", pId=" + pId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", quantity=" + quantity + ", orderId=" + orderId + ", buyerId=" + buyerId + "]";
	}
	
	
	public Cart(Integer cId, Integer pId, String productName, Double productPrice, Integer quantity, Order orderId,
			Buyer buyerId) {
		super();
		this.cId = cId;
		this.pId = pId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.quantity = quantity;
		this.orderId = orderId;
		this.buyerId = buyerId;
	}
	
	
	
	
	
	
	
}
