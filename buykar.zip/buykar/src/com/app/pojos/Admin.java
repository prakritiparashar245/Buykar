package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="admin",schema = "system")
public class Admin {

	private Integer aid;
	private String email;
	private String password;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer getAid() {
		return aid;
	}
	public void setAid(Integer aid) {
		this.aid = aid;
	}
	@Column(length = 20)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Column(length = 20)
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Admin [aid=" + aid + ", email=" + email + ", password=" + password + "]";
	}
	public Admin(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}
	public Admin()
	{
		System.out.println("admin");
	}
}
