package com.app.pojos;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="seller",schema = "system")
public class Seller {

	private String email;
	private String name;
	private String address;
	private String password;
	private Integer sid;
	private String adharCard;
	private String phoneNo;
	@JsonIgnore
	private List<Product> lop=new ArrayList<>() ;
	
	public Seller()
	{
		System.out.println("seller");
	}
	
	
	
	


	public Seller(String email, String name, String address, String password, String adharCard, String phoneNo,
			List<Product> lop) {
		super();
		this.email = email;
		this.name = name;
		this.address = address;
		this.password = password;
		this.adharCard = adharCard;
		this.phoneNo = phoneNo;
		this.lop = lop;
	}






	@Column(length = 20,unique  = true)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Column(length = 20)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(length = 100)
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Column(length = 20)
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Integer getSid() {
		return sid;
	}
	public void setSid(Integer sid) {
		this.sid = sid;
	}
	@Column(length = 20)
	public String getAdharCard() {
		return adharCard;
	}

	public void setAdharCard(String adharCard) {
		this.adharCard = adharCard;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public void AddProduct(Product p)
	{
		System.out.println(p);
		this.lop.add(p);
		p.setSid(this);
	}

	@OneToMany(mappedBy = "sid",cascade = CascadeType.ALL)
	 public List<Product> getLop()
	 { return lop; } 
	 
	 public void setLop(List<Product> lop)
	 { this.lop = lop; }
	@Override
	public String toString() {
		return "Seller [email=" + email + ", name=" + name + ", address=" + address + ", password=" + password
				+ ", sid=" + sid + ", adharCard=" + adharCard + ", phoneNo=" + phoneNo + ", lop=" + lop + "]";
	}
	 
	
	
}
